package hello;

public class Greeter {
  public String sayHello() {
  return "Gradle Hello world!";
  }
}