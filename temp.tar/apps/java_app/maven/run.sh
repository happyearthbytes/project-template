MAVEN="maven"
${MAVEN} clean
${MAVEN} package
