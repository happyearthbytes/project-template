package helloworld;

public class Greeter {
  public String sayHello() {
  return "Maven Hello world!";
  }
}