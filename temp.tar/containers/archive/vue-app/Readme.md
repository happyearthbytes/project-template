> sudo yum install npm
> sudo npm install -g @vue/cli