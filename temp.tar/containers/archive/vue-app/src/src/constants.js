export const MsgDestinations = [
  "/topic/test.demo",
];
export const LogCategories = [
  "general",
  "debug",
  "amq",
];
export const LogStatuses = [
  "info",
  "warning",
  "error",
  "debug",
  "manual",
];