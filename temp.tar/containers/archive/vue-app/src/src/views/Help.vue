<template>
  <v-container fluid>
    <v-container> Link to Help documentation </v-container>
  </v-container>
</template>

<script>
export default {
  name: "Help",
};
</script>