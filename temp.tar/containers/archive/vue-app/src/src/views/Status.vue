<template>
  <v-container fluid>
    <v-container> Status </v-container>
  </v-container>
</template>

<script>
export default {
  name: "Status",
};
</script>