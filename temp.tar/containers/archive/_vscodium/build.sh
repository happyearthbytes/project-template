#!/usr/bin/env bash
podman build . -t vscodium