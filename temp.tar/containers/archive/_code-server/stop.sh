podman pod stop code-server
podman pod rm code-server