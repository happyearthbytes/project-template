#! /usr/bin/env bash
# This is an example tool that simply echoes back the provided arguments
echo $@