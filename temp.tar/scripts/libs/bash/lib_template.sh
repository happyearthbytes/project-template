#!/usr/bin/env bash

_example_lib_function()
{
  echo "hello"
}
