#!/usr/bin/env bash
./scripts/tools/setup.sh

# TODO git config --global core.editor "code --wait"

# TODO - match origin
# git fetch origin
# git reset --hard origin/master
